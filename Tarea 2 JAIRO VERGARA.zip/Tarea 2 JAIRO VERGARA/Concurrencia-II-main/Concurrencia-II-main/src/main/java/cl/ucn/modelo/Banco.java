package cl.ucn.modelo;

import org.apache.logging.log4j.Logger;
import java.util.concurrent.locks.*;
public class Banco {

	private final double[] cuentas;
	private final ReentrantLock transferencia_en_proceso;
	public Banco() {

		cuentas = new double[100];
		for (int i=0; i<cuentas.length; i++) {
			cuentas[i] = 2000;
		}
		transferencia_en_proceso = new ReentrantLock();
	}


	public  void transferencia(int cuentaOrigen, int cuentaDestino, double cantidad, Logger logger)
			throws InterruptedException {
		transferencia_en_proceso.lock();
		try {
			if (cuentas[cuentaOrigen] < cantidad)
				return;
			cuentas[cuentaOrigen] -= cantidad;
			logger.info(Thread.currentThread());
			logger.info("Transferencia: %10.2f de %d para %d", cantidad, cuentaOrigen, cuentaDestino);
			cuentas[cuentaDestino] += cantidad;
			logger.info("Saldo total: %10.2f%n", this.getSaldoTotal());
		}finally {
			transferencia_en_proceso.unlock();
		}
	}

	public double getSaldoTotal() {
		
		double sumaCuentas = 0;
		for (double a: this.cuentas)
			sumaCuentas+=a;	
		
		return sumaCuentas;	
	}
	
	public void setCantidad(int cuenta, double cantidad) {
		
		this.cuentas[cuenta] = cantidad;
	}

}
