package cl.ucn.tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestTransferenciaExistosa {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
