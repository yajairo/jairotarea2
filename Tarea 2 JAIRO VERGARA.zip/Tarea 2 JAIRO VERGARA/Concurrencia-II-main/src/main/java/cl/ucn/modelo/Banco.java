package cl.ucn.modelo;

import org.apache.logging.log4j.Logger;
import java.util.concurrent.locks.ReentrantLock;
import java.io.FileWriter;
import java.io.IOException;

public class Banco {
	private final double[] cuentas;
	private final ReentrantLock[] locks;

	public Banco() {
		cuentas = new double[100];
		locks = new ReentrantLock[cuentas.length];
		for (int i = 0; i < cuentas.length; i++) {
			cuentas[i] = 2000;
			locks[i] = new ReentrantLock();
		}
	}

	public void transferencia(int cuentaOrigen, int cuentaDestino, double cantidad, Logger logger) {
		if (cuentaOrigen == cuentaDestino) return;
		locks[cuentaOrigen].lock();
		try {
			if (cuentas[cuentaOrigen] < cantidad)
				return;
			cuentas[cuentaOrigen] -= cantidad;
			locks[cuentaDestino].lock();
			try {
				cuentas[cuentaDestino] += cantidad;
				registrarTransferencia(cuentaOrigen, cuentaDestino, cantidad, logger);
			} finally {
				locks[cuentaDestino].unlock();
			}
		} finally {
			locks[cuentaOrigen].unlock();
		}
	}

	private void registrarTransferencia(int cuentaOrigen, int cuentaDestino, double cantidad, Logger logger) {
		logger.info(Thread.currentThread());
		logger.info("Transferencia: %10.2f de %d para %d", cantidad, cuentaOrigen, cuentaDestino);
		logger.info("Saldo total: %10.2f%n", this.getSaldoTotal());

		try (FileWriter writer = new FileWriter("registros/transacciones.log", true)) {
			writer.write(String.format("Transferencia: Cuenta %d -> Cuenta %d, Monto: %.2f%n", cuentaOrigen, cuentaDestino, cantidad));
			writer.write(String.format("Saldo Cuenta %d: %.2f, Saldo Cuenta %d: %.2f%n", cuentaOrigen, cuentas[cuentaOrigen], cuentaDestino, cuentas[cuentaDestino]));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public double getSaldoTotal() {
		double sumaCuentas = 0;
		for (double a : this.cuentas)
			sumaCuentas += a;
		return sumaCuentas;
	}

	public void setCantidad(int cuenta, double cantidad) {
		this.cuentas[cuenta] = cantidad;
	}
}
